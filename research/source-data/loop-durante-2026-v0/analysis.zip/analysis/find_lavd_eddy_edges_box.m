function eddies = find_lavd_eddy_edges_box(XX, YY, LAVD, lonbox, latbox, varargin)
% FIND_LAVD_EDDY_EDGES_BOX
% Find candidate eddy edges from LAVD inside a user-defined box.
%
% INPUTS
%   XX, YY   : lon/lat grids [ny x nx]
%   LAVD     : LAVD field  [ny x nx]
%   lonbox   : [lonmin lonmax]
%   latbox   : [latmin latmax]
%
% OPTIONAL NAME-VALUE PAIRS
%   'SmoothSigma'       : Gaussian smoothing sigma in grid cells (default 1.0)
%   'MinPeakFrac'       : minimum local-max value as fraction of box max (default 0.55)
%   'NLevels'           : number of contour levels (default 40)
%   'MinLevelFrac'      : minimum contour level as fraction of box max (default 0.35)
%   'MaxLevelFrac'      : maximum contour level as fraction of box max (default 0.98)
%   'MinAreaKm2'        : minimum contour area [km^2] (default 300)
%   'MinCompactness'    : minimum 4*pi*A/P^2 (default 0.12)
%   'MaxConvexDef'      : maximum convex deficiency (default 0.25)
%   'PlotIt'            : true/false (default true)
%
% OUTPUT
%   eddies : struct array with fields
%       .peak_lon
%       .peak_lat
%       .peak_lavd
%       .edge_lon
%       .edge_lat
%       .level
%       .area_km2
%       .compactness
%       .convex_def
%
% EXAMPLE
%   eddies = find_lavd_eddy_edges_box(XX,YY,LAVD, ...
%       [-87.6054 -82.3021],[18.4022 22.4019], ...
%       'PlotIt',true);
% G. Durante, 2025
% -------------------- options --------------------
p = inputParser;
addParameter(p,'SmoothSigma',1.0);
addParameter(p,'MinPeakFrac',0.55);
addParameter(p,'NLevels',40);
addParameter(p,'MinLevelFrac',0.35);
addParameter(p,'MaxLevelFrac',0.98);
addParameter(p,'MinAreaKm2',300);
addParameter(p,'MinCompactness',0.12);
addParameter(p,'MaxConvexDef',0.25);
addParameter(p,'PlotIt',true);
parse(p,varargin{:});
opt = p.Results;

% -------------------- subset ---------------------
inbox = XX >= lonbox(1) & XX <= lonbox(2) & YY >= latbox(1) & YY <= latbox(2);

if ~any(inbox(:))
    error('The requested box does not intersect the grid.')
end

rows = any(inbox,2);
cols = any(inbox,1);

X = XX(rows, cols);
Y = YY(rows, cols);
L = LAVD(rows, cols);

% mask points outside exact box
inside_exact = X >= lonbox(1) & X <= lonbox(2) & Y >= latbox(1) & Y <= latbox(2);
L(~inside_exact) = NaN;

if all(~isfinite(L(:)))
    error('No valid LAVD values inside the requested box.')
end

% -------------------- smooth LAVD ----------------
K = gaussian_kernel_2d(opt.SmoothSigma);
Ls = nanconv2(L, K);

% -------------------- local maxima ---------------
peakMask = local_max_2d(Ls);

Lmax_box = max(Ls(:), [], 'omitnan');
peakMask = peakMask & isfinite(Ls) & (Ls >= opt.MinPeakFrac * Lmax_box);

[ri, ci] = find(peakMask);
peakLon = X(peakMask);
peakLat = Y(peakMask);
peakVal = Ls(peakMask);
% candidate = struct([]);
candidate = struct( ...
    'peak_id', {}, ...
    'peak_lon', {}, ...
    'peak_lat', {}, ...
    'peak_lavd', {}, ...
    'edge_lon', {}, ...
    'edge_lat', {}, ...
    'level', {}, ...
    'area_km2', {}, ...
    'compactness', {}, ...
    'convex_def', {});


if isempty(peakLon)
    warning('No local LAVD maxima passed the threshold inside the box.')
    eddies = candidate([]);
    return
end

% -------------------- contour levels -------------
levels = linspace(opt.MinLevelFrac * Lmax_box, opt.MaxLevelFrac * Lmax_box, opt.NLevels);

% local Cartesian coordinates for area/perimeter
lon0 = mean(lonbox);
lat0 = mean(latbox);


icand = 0;

for ilev = 1:numel(levels)
    lev = levels(ilev);
    S = get_closed_contours(X, Y, Ls, lev);

    for j = 1:numel(S)
        xy = S(j).xy;

        % how many detected maxima are inside this contour?
        inpk = inpolygon(peakLon, peakLat, xy(:,1), xy(:,2));
        npk  = sum(inpk);

        if npk ~= 1
            continue
        end

        ipk = find(inpk,1,'first');

        % area and perimeter in meters
        [xm, ym] = lonlat2xy_local(xy(:,1), xy(:,2), lon0, lat0);
        A  = polyarea(xm, ym);      % m^2
        P  = sum(hypot(diff(xm), diff(ym)));  % m

        if P <= 0 || A <= 0
            continue
        end

        compactness = 4*pi*A/(P^2);

        k = convhull(xm, ym);
        Ah = polyarea(xm(k), ym(k));
        convex_def = (Ah - A) / Ah;

        area_km2 = A / 1e6;

        if area_km2 < opt.MinAreaKm2
            continue
        end
        if compactness < opt.MinCompactness
            continue
        end
        if convex_def > opt.MaxConvexDef
            continue
        end

        icand = icand + 1;
        candidate(icand).peak_id      = ipk;
        candidate(icand).peak_lon     = peakLon(ipk);
        candidate(icand).peak_lat     = peakLat(ipk);
        candidate(icand).peak_lavd    = peakVal(ipk);
        candidate(icand).edge_lon     = xy(:,1);
        candidate(icand).edge_lat     = xy(:,2);
        candidate(icand).level        = lev;
        candidate(icand).area_km2     = area_km2;
        candidate(icand).compactness  = compactness;
        candidate(icand).convex_def   = convex_def;
    end
end

if isempty(candidate)
    warning('No valid closed LAVD contours were found.')
    eddies = candidate([]);
    return
end

% -------------------- outermost valid contour per peak --------------------
peak_ids = unique([candidate.peak_id]);
eddies = candidate([]);

for k = 1:numel(peak_ids)
    idk = peak_ids(k);
    I = find([candidate.peak_id] == idk);

    % choose the outermost valid contour = largest area
    [~, imax] = max([candidate(I).area_km2]);
    eddies(k) = candidate(I(imax));
end

% sort by area, large to small
[~, isrt] = sort([eddies.area_km2], 'descend');
eddies = eddies(isrt);

% -------------------- plot -----------------------
if opt.PlotIt
    figure
    pcolor(X, Y, L), shading flat
    hold on
    contour(X, Y, Ls, 12, 'k-')
    for k = 1:numel(eddies)
        plot(eddies(k).edge_lon, eddies(k).edge_lat, 'w-', 'LineWidth', 2)
        plot(eddies(k).peak_lon, eddies(k).peak_lat, 'wo', ...
            'MarkerFaceColor', 'r', 'MarkerSize', 6)
        text(eddies(k).peak_lon, eddies(k).peak_lat, sprintf(' %d',k), ...
            'Color','w','FontWeight','bold','VerticalAlignment','bottom')
    end
    xlim(lonbox)
    ylim(latbox)
    colorbar
    title('Candidate LAVD eddy edges')
    xlabel('Longitude')
    ylabel('Latitude')
end

end

% ============================================================
function peakMask = local_max_2d(Z)
% strict 8-neighbor local maxima
[ny,nx] = size(Z);
peakMask = false(ny,nx);

for i = 2:ny-1
    for j = 2:nx-1
        z0 = Z(i,j);
        if ~isfinite(z0)
            continue
        end

        nb = Z(i-1:i+1, j-1:j+1);
        nb(2,2) = -Inf;

        if all(z0 >= nb(:)) && any(z0 > nb(:))
            peakMask(i,j) = true;
        end
    end
end
end

% ============================================================
function K = gaussian_kernel_2d(sig)
if sig <= 0
    K = 1;
    return
end
n = max(1, ceil(3*sig));
[x,y] = meshgrid(-n:n, -n:n);
K = exp(-(x.^2 + y.^2)/(2*sig^2));
K = K / sum(K(:));
end

% ============================================================
function Zs = nanconv2(Z, K)
M = isfinite(Z);
Z0 = Z;
Z0(~M) = 0;

num = conv2(Z0, K, 'same');
den = conv2(double(M), K, 'same');

Zs = num ./ den;
Zs(den == 0) = NaN;
end

% ============================================================
function S = get_closed_contours(X, Y, Z, level)
C = contourc(X(1,:), Y(:,1), Z, [level level]);

S = struct('level',{},'xy',{});
k = 1;
ic = 0;

while k < size(C,2)
    lev = C(1,k);
    npt = C(2,k);
    pts = C(:,k+1:k+npt)';
    k = k + npt + 1;

    if size(pts,1) < 4
        continue
    end

    % force closure if almost closed
    if hypot(pts(1,1)-pts(end,1), pts(1,2)-pts(end,2)) < 1e-6
        ic = ic + 1;
        S(ic).level = lev;
        S(ic).xy    = pts;
    end
end
end

% ============================================================
function [x, y] = lonlat2xy_local(lon, lat, lon0, lat0)
R = 6371000; % m
x = R * cosd(lat0) * deg2rad(lon - lon0);
y = R * deg2rad(lat - lat0);
end