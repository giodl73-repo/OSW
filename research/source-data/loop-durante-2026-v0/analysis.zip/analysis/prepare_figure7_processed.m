%% Build compact time-normalized event composites for manuscript Figure 7
% G. Durante, 2026

clear; clc;

sourceFile = 'D:\Chamba\Datos\AVISO_Updated_2025-2026\ReducedDomains\Alti_lc_car_fullp.mat';
mode2File = 'D:\Papers\Paper_II\Programas\Figures\cleanV\mca_mode2_results.mat';
outputFile = ['D:\Papers\Paper_II\Programas\Figures\Submission\CodesRep\' ...
    'ZenodoRepository\data\processed\Figure7_processed.mat'];

positivePeakDates = [729040,730254,730556,730851,732058,733112,733674, ...
    734226,734551,734785,735013,735274,735689,736119,736413,736919, ...
    737790,738172,738634,738847,739433,739541,739783]' + 20;
positiveOnsetDates = [728993,730153,730475,730808,732039,733040,733653, ...
    734159,734507,734756,734979,735244,735663,736106,736368,736890, ...
    737755,738105,738591,738802,739400,739515,739763]';

negativePeakDates = [728233,728524,729653,729969,731056,731416,731767, ...
    732171,734707,735766,736194,737605,738007,738410,738755,739159,739479]' + 20;
negativeOnsetDates = [728196,728485,729618,729943,731023,731380,731727, ...
    732155,734671,735731,736134,737551,737986,738376,738718,739130,739453]';

file = matfile(sourceFile);
xdu = file.xdu;
ydu = file.ydu;
inma = file.inma;
htime = file.htime;

mode2 = load(mode2File,'B2_f');
projectedPC = -mode2.B2_f(:);

adMean = streamingMean(file,'ad',size(inma,1),numel(htime),500);
positive = buildComposite(file,htime,positiveOnsetDates,positivePeakDates,adMean);
negative = buildComposite(file,htime,negativeOnsetDates,negativePeakDates,adMean);

metadata = struct( ...
    'author','G. Durante, 2026', ...
    'description','Time-normalized positive and negative mode-2 event evolution for Figure 7.', ...
    'source',sourceFile, ...
    'stagesPercent',[0 25 50 75 100]);

save(outputFile,'xdu','ydu','inma','htime','projectedPC', ...
    'positive','negative','metadata','-v7.3');

function meanField = streamingMean(file,field,nSpace,nTime,chunkSize)
total = zeros(nSpace,1);
count = zeros(nSpace,1);
for first = 1:chunkSize:nTime
    last = min(nTime,first+chunkSize-1);
    values = file.(field)(:,first:last);
    good = isfinite(values);
    values(~good) = 0;
    total = total + sum(values,2);
    count = count + sum(good,2);
end
meanField = total ./ count;
meanField(count == 0) = NaN;
end

function output = buildComposite(file,htime,onsetDates,peakDates,adMean)
nStage = 5;
dims = size(file,'ad');
nSpace = dims(1);
fields = {'ad','mg','ug','vg'};
sums = struct;
for i = 1:numel(fields)
    sums.(fields{i}) = zeros(nSpace,nStage);
end
pc = nan(nStage,numel(peakDates));
durations = nan(numel(peakDates),1);
mode2 = load('D:\Papers\Paper_II\Programas\Figures\cleanV\mca_mode2_results.mat','B2_f');
projectedPC = -mode2.B2_f(:);

for event = 1:numel(peakDates)
    first = find(fix(htime) == fix(onsetDates(event)),1);
    last = find(fix(htime) == fix(peakDates(event)),1);
    assert(~isempty(first) && ~isempty(last) && last >= first, ...
        'Invalid event interval %s to %s.',datestr(onsetDates(event)),datestr(peakDates(event)));
    sourceIndex = first:last;
    sourceAxis = 1:numel(sourceIndex);
    stageAxis = linspace(1,numel(sourceIndex),nStage);
    for i = 1:numel(fields)
        values = file.(fields{i})(:,sourceIndex);
        normalized = interp1(sourceAxis,values',stageAxis,'linear')';
        sums.(fields{i}) = sums.(fields{i}) + normalized;
    end
    pc(:,event) = interp1(sourceAxis,projectedPC(sourceIndex),stageAxis,'linear')';
    durations(event) = peakDates(event)-onsetDates(event);
end

output = struct;
output.adAbs = sums.ad/numel(peakDates);
output.adAnom = output.adAbs-adMean;
output.speed = sums.mg/numel(peakDates);
output.u = sums.ug/numel(peakDates);
output.v = sums.vg/numel(peakDates);
output.pc = pc;
output.onsetDates = onsetDates;
output.peakDates = peakDates;
output.durations = durations;
output.n = numel(peakDates);
end
