%% Build compact, figure-ready data files for the Zenodo repository
% G. Durante, 2026

clear; clc;

sourceRoot = 'D:\Papers\Paper_II\Programas\Figures';
codeRoot = fullfile(sourceRoot, 'Submission', 'CodesRep');
cleanRoot = fullfile(sourceRoot, 'cleanV');
avisoRoot = 'D:\Chamba\Datos\AVISO_Updated_2025-2026';
outputRoot = fullfile(codeRoot, 'ZenodoRepository', 'data', 'processed');

if ~isfolder(outputRoot)
    mkdir(outputRoot);
end

author = 'G. Durante, 2026';
created = datestr(now, 30);

%% Figures 2-4: leading MCA mode and deep-transport relationships

sourceFile = fullfile(codeRoot, 'mca_yuc_lc_results.mat');
S = load(sourceFile);

largeDailyFields = {'Vy', 'Vyf', 'Vf', 'B_ext', 'B_ext_f'};
largeDailyFields = largeDailyFields(isfield(S, largeDailyFields));
S = rmfield(S, largeDailyFields);

axisData = load(fullfile(codeRoot, 'YC_CC_Axis.mat'));
S.CurAxisPositive = [mean(axisData.MaxAx(:, S.inmax_lc), 2, 'omitnan'), ...
                     mean(axisData.MaxAy(:, S.inmax_lc), 2, 'omitnan')];
S.CurAxisNegative = [mean(axisData.MaxAx(:, S.inmin_lc), 2, 'omitnan'), ...
                     mean(axisData.MaxAy(:, S.inmin_lc), 2, 'omitnan')];
clear axisData

temperatureFile = fullfile(sourceRoot, '..', 'Methods', 'Data', 'Derived', ...
    'DatosTempRaw', 'Tempos.mat');
if isfile(temperatureFile)
    T = load(temperatureFile, 'Tprof');
    S.Tmean = mean(T.Tprof, 3, 'omitnan');
    clear T
end

S.metadata = struct( ...
    'author', author, ...
    'created', created, ...
    'description', 'Figure-ready leading MCA mode, composites, and deep-transport diagnostics.', ...
    'source', sourceFile, ...
    'omittedFields', {largeDailyFields});

save(fullfile(outputRoot, 'Figures2_4_processed.mat'), '-struct', 'S', '-v7.3');
clear S

%% Figures 5-7: second MCA mode

mainFile = fullfile(outputRoot, 'Figures2_4_processed.mat');
mode2File = fullfile(cleanRoot, 'mca_mode2_results.mat');

baseNames = {'xdu','ydu','inma','xduf','yduf','inmaf', ...
    'Xy','Zy','celday','Xf','Zf','celdaf','xsecy','ysecy','xsecf','ysecf', ...
    'tid','tisp','htimef','E_1','E_2','T_1','T_2','VE','EV_LC','EV_yuc','ycT','lags'};
M = load(mainFile, baseNames{:});
M2 = load(mode2File);
fields = fieldnames(M2);
for i = 1:numel(fields)
    M.(fields{i}) = M2.(fields{i});
end
M.metadata = struct( ...
    'author', author, ...
    'created', created, ...
    'description', 'Figure-ready second MCA mode, composites, lag maps, and event evolution.', ...
    'source', mode2File);
save(fullfile(outputRoot, 'Figures5_7_processed.mat'), '-struct', 'M', '-v7.3');
clear M M2

%% Figure 8: lagged correlation maps

base = load(mainFile, 'xcury', 'ycT', 'tid');
regionalFile = fullfile(avisoRoot, 'ReducedDomains', 'Alti_lc_car.mat');
R = load(regionalFile, 'mg', 'htime', 'xdu', 'ydu', 'inma');

dateIndex = nan(numel(base.tid), 1);
for i = 1:numel(base.tid)
    j = find(fix(R.htime) == fix(base.tid(i)), 1, 'first');
    assert(~isempty(j), 'Missing regional AVISO date %s.', datestr(base.tid(i)));
    dateIndex(i) = j;
end

mg = R.mg(:, dateIndex);
xcury = base.xcury(:);
ycT = base.ycT(:);
lags = [-40 -20 0 20 40];
nx = size(mg, 1);
RR_x = nan(nx, numel(lags));
RR_y = nan(nx, numel(lags));
RR_multi = nan(nx, numel(lags));

for ix = 1:nx
    fieldSeries = mg(ix, :)';
    for ilag = 1:numel(lags)
        lag = lags(ilag);
        if lag < 0
            response = fieldSeries(1:end+lag);
            p1 = xcury(1-lag:end);
            p2 = ycT(1-lag:end);
        elseif lag > 0
            response = fieldSeries(1+lag:end);
            p1 = xcury(1:end-lag);
            p2 = ycT(1:end-lag);
        else
            response = fieldSeries;
            p1 = xcury;
            p2 = ycT;
        end

        good = isfinite(response) & isfinite(p1) & isfinite(p2);
        if nnz(good) <= 3
            continue
        end

        response = response(good);
        predictors = [p1(good), p2(good)];
        RR_x(ix, ilag) = corr(response, predictors(:, 1));
        RR_y(ix, ilag) = corr(response, predictors(:, 2));
        predictors = normalize(predictors);
        design = [ones(size(predictors, 1), 1), predictors];
        if rank(design) == 3
            fitted = design * (design \ response);
            RR_multi(ix, ilag) = corr(fitted, response);
        end
    end
end

xdu = R.xdu;
ydu = R.ydu;
inma = R.inma;
metadata = struct( ...
    'author', author, ...
    'created', created, ...
    'description', 'Lagged correlations used in Figure 8.', ...
    'lagConvention', 'Negative: surface field leads; positive: Yucatan metric leads.', ...
    'source', regionalFile);
save(fullfile(outputRoot, 'Figure8_processed.mat'), ...
    'xdu','ydu','inma','lags','RR_x','RR_y','RR_multi','metadata','-v7.3');
clear R base mg xcury ycT RR_x RR_y RR_multi

%% Figure 9: PLS skill maps, examples, and LC-area timeline

plsFile = fullfile(codeRoot, 'YC_FC_to_LC_direct_AVISO_PLS_fullfield_results_asgas.mat');
P = load(plsFile, 'Out');
Results = P.Out.Results;
allLeads = arrayfun(@(s) s.lead, Results);
leads = [0 20 40];
exampleDates = [datenum('07-Aug-2018'), 737608, 737928];

F9 = struct;
grid = load(mainFile, 'xdu', 'ydu', 'inma', 'tid');
F9.xdu = grid.xdu;
F9.ydu = grid.ydu;
F9.inma = grid.inma;
F9.leads = leads;
F9.exampleDates = exampleDates;

for i = 1:numel(leads)
    index = find(allLeads == leads(i), 1);
    assert(~isempty(index), 'PLS lead %d is unavailable.', leads(i));
    result = Results(index);
    F9.skillR2(:, i) = columnCorrelation(result.Obs.mg, result.Pred.mg).^2;

    if leads(i) <= 20
        for j = 1:numel(exampleDates)
            dateIndex = find(result.tPredictor == exampleDates(j), 1);
            assert(~isempty(dateIndex), 'Example date %s is unavailable for lead %d.', ...
                datestr(exampleDates(j)), leads(i));
            if leads(i) == 0
                F9.observed(j) = extractFields(result.Obs, dateIndex);
            end
            F9.predicted(i, j) = extractFields(result.Pred, dateIndex);
        end
    end
end

trackingFile = fullfile(avisoRoot, 'LCStatistics', 'tracking_stats_AVISO_93_23_n.mat');
tracking = load(trackingFile, 'htime', 'AMR_loop', 'area_loop');
timeline = (grid.tid(1):grid.tid(end))';
F9.timeline = timeline;
F9.LCEddyArea = interp1(tracking.htime, tracking.AMR_loop, timeline);
F9.LCArea = interp1(tracking.htime, tracking.area_loop, timeline);
F9.testPeriod = [Results(1).tPredictor(1), Results(1).tPredictor(end)];

section = load(fullfile(codeRoot, 'mca_yuc_lc_results.mat'), 'Vf', 'tid');
gap = find(isnan(mean(section.Vf, 1, 'omitnan')) | all(isnan(section.Vf), 1));
if isempty(gap)
    F9.canekGap = [NaN NaN];
else
    F9.canekGap = [section.tid(gap(1)), section.tid(gap(end))];
end

F9.metadata = struct( ...
    'author', author, ...
    'created', created, ...
    'description', 'Only Figure 9 skill maps, example fields, and timeline variables.', ...
    'source', plsFile);
save(fullfile(outputRoot, 'Figure9_processed.mat'), '-struct', 'F9', '-v7.3');
clear P Results F9 section tracking grid

%% Figure 10: event matches, ring geometry, and composites

figure10File = fullfile(cleanRoot, 'figure10_curated_event_results_43d.mat');
F10 = load(figure10File, 'Figure10');
regionalGrid = load(fullfile(avisoRoot, 'ReducedDomains', 'Alti_lc_car_fullp.mat'), ...
    'xdu', 'ydu');
Figure10 = F10.Figure10;
xdu = regionalGrid.xdu;
ydu = regionalGrid.ydu;
metadata = struct( ...
    'author', author, ...
    'created', created, ...
    'description', 'Figure 10 event matches, detachment geometry, and four composites.', ...
    'source', figure10File);
save(fullfile(outputRoot, 'Figure10_processed.mat'), ...
    'Figure10','xdu','ydu','metadata','-v7.3');

fprintf('\nProcessed files written to:\n%s\n', outputRoot);

function fields = extractFields(source, index)
names = {'ad','ug','vg','mg'};
fields = struct;
for i = 1:numel(names)
    fields.(names{i}) = source.(names{i})(index, :)';
end
end

function r = columnCorrelation(a, b)
good = isfinite(a) & isfinite(b);
n = sum(good, 1);
a(~good) = 0;
b(~good) = 0;
meanA = sum(a, 1) ./ n;
meanB = sum(b, 1) ./ n;
da = (a - meanA) .* good;
db = (b - meanB) .* good;
den = sqrt(sum(da.^2, 1) .* sum(db.^2, 1));
r = sum(da .* db, 1) ./ den;
r(n < 3 | den == 0) = NaN;
r = r(:);
end
