function prepare_FigureS4_processed
% Extract the compact variables required for Supplementary Figure S4.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
codeRoot = fileparts(root);
sourceFile = fullfile(codeRoot, ...
    'YC_FC_to_LC_direct_AVISO_PLS_fullfield_results_asgas.mat');
figure9File = fullfile(root,'data','Figure9_processed.mat');
outputFile = fullfile(root,'data','FigureS4_processed.mat');

base = load(figure9File,'xdu','ydu','inma','leads','skillR2','exampleDates', ...
    'observed','timeline','LCArea','LCEddyArea','testPeriod','canekGap');
source = load(sourceFile,'Out');
results = source.Out.Results;
allLeads = arrayfun(@(item) item.lead,results);

lead = 40;
leadIndex = find(allLeads == lead,1);
assert(~isempty(leadIndex),'The source result does not contain a 40-day lead.');
result = results(leadIndex);

zeroIndex = find(base.leads == 0,1);
skillIndex = find(base.leads == lead,1);
assert(~isempty(zeroIndex) && ~isempty(skillIndex), ...
    'Figure9_processed.mat does not contain the required skill maps.');

exampleDates = base.exampleDates;
predicted = repmat(struct('mg',[],'ug',[],'vg',[],'ad',[]),1,numel(exampleDates));
predictorDates = nan(size(exampleDates));
targetDates = nan(size(exampleDates));

for index = 1:numel(exampleDates)
    dateIndex = find(result.tTarget == exampleDates(index),1);
    assert(~isempty(dateIndex),'Target date %s is unavailable for lead 40.', ...
        datestr(exampleDates(index)));
    predicted(index) = extractFields(result.Pred,dateIndex);
    predictorDates(index) = result.tPredictor(dateIndex);
    targetDates(index) = result.tTarget(dateIndex);
end

xdu = base.xdu;
ydu = base.ydu;
inma = base.inma;
observed = base.observed;
timeline = base.timeline;
LCArea = base.LCArea;
LCEddyArea = base.LCEddyArea;
testPeriod = base.testPeriod;
canekGap = base.canekGap;
skillR2 = base.skillR2(:,skillIndex);
meanR2 = mean(skillR2,'omitnan');
meanR2Zero = mean(base.skillR2(:,zeroIndex),'omitnan');
relativeReduction = 100*(meanR2Zero-meanR2)/meanR2Zero;
metadata = struct( ...
    'author','G. Durante, 2026', ...
    'created',datestr(now,30), ...
    'description','Forty-day testing skill and three example reconstructions for Figure S4.', ...
    'source',sourceFile, ...
    'dateSelection','Examples are matched by target date; predictor dates occur 40 days earlier.');

save(outputFile,'xdu','ydu','inma','lead','skillR2','meanR2', ...
    'meanR2Zero','relativeReduction','exampleDates','predictorDates', ...
    'targetDates','observed','predicted','timeline','LCArea','LCEddyArea', ...
    'testPeriod','canekGap','metadata','-v7.3');

fprintf('Figure S4 processed data written to %s\n',outputFile);
end

function output = extractFields(input,index)
output = struct( ...
    'mg',input.mg(index,:), ...
    'ug',input.ug(index,:), ...
    'vg',input.vg(index,:), ...
    'ad',input.ad(index,:));
end
