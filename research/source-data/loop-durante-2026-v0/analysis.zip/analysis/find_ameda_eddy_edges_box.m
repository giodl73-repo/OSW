function eddies = find_ameda_eddy_edges_box(XX,YY,U,V,A,lonbox,latbox,varargin)
% FIND_AMEDA_EDDY_EDGES_BOX
% Light AMEDA-style eddy detection for a single snapshot.
%
% Usage:
%   eddies = find_ameda_eddy_edges_box(XX,YY,U,V,lonbox,latbox)
%
% Inputs
%   XX, YY  : lon/lat grids [ny x nx]
%   U, V    : zonal/meridional velocities [ny x nx] in m/s
%   lonbox  : [lonmin lonmax]
%   latbox  : [latmin latmax]
%
% Optional name-value pairs
%   'SearchRadiusKm'  : LNAM neighborhood radius (default 50)
%   'SmoothSigma'     : Gaussian smoothing in grid cells for U,V (default 1.0)
%   'MinAbsLNAM'      : minimum |LNAM| for candidate centers (default 0.70)
%   'NLevels'         : number of contour levels for streamline search (default 80)
%   'MinAreaKm2'      : minimum contour area (default 200)
%   'MinCompactness'  : minimum 4*pi*A/P^2 (default 0.10)
%   'MaxConvexDef'    : maximum convex deficiency (default 0.35)
%   'PlotIt'          : true/false (default true)
%
% Output
%   eddies : struct array with fields
%       .center_lon
%       .center_lat
%       .sign                % +1 cyclone, -1 anticyclone
%       .lnam
%       .low
%       .char_lon
%       .char_lat
%       .char_level
%       .char_mean_speed
%       .outer_lon
%       .outer_lat
%       .outer_level
%       .outer_area_km2
%       .outer_compactness
%       .outer_convex_def
% G. Durante, 2025
% ---------------- options ----------------
p = inputParser;
addParameter(p,'SearchRadiusKm',50);
addParameter(p,'SmoothSigma',1.0);
addParameter(p,'MinAbsLNAM',0.70);
addParameter(p,'NLevels',80);
addParameter(p,'MinAreaKm2',200);
addParameter(p,'MinCompactness',0.10);
addParameter(p,'MaxConvexDef',0.35);
addParameter(p,'PlotIt',true);
parse(p,varargin{:});
opt = p.Results;

% ---------------- subset with small padding ----------------
inbox = XX >= lonbox(1) & XX <= lonbox(2) & YY >= latbox(1) & YY <= latbox(2);
if ~any(inbox(:))
    error('Requested box does not intersect the grid.');
end

r0 = find(any(inbox,2));
c0 = find(any(inbox,1));

pad = 2;
r1 = max(1, r0(1)-pad);
r2 = min(size(XX,1), r0(end)+pad);
c1 = max(1, c0(1)-pad);
c2 = min(size(XX,2), c0(end)+pad);

X  = XX(r1:r2, c1:c2);
Y  = YY(r1:r2, c1:c2);
UU = U (r1:r2, c1:c2);
VV = V (r1:r2, c1:c2);
AA = A (r1:r2, c1:c2);

inside_exact = X >= lonbox(1) & X <= lonbox(2) & Y >= latbox(1) & Y <= latbox(2);

% ---------------- smooth U,V lightly ----------------
if opt.SmoothSigma > 0
    K  = gaussian_kernel_2d(opt.SmoothSigma);
    UU = nanconv2(UU, K);
    VV = nanconv2(VV, K);
end

% ---------------- local Cartesian coords ----------------
lon0 = mean(lonbox);
lat0 = mean(latbox);
[xm, ym] = lonlat2xy_local(X, Y, lon0, lat0);

xvec = xm(1,:);   % columns
yvec = ym(:,1);   % rows

% ---------------- gradients and LOW ----------------
[dUdx, dUdy] = gradient(UU);
[dVdx, dVdy] = gradient(VV);


dx =  nan(size(X));
dy =  nan(size(Y));
hlon = X(1, :);
hlat = Y(:, 1);

for i = 1 : length(hlat)
    dx(i, :) = spheric_dist(hlat(i),hlat(i),hlon(1),hlon(2));
end

for i = 1 : length(hlon)
    dy(:, i) = spheric_dist(hlat(1),hlat(2),hlon(i),hlon(i));
end

dUdy = dUdy./dy; 
dUdx = dUdx./dx;

dVdy = dVdy./dy;
dVdx = dVdx./dx; 

zeta = dVdx - dUdy;
sn   = dUdx - dVdy;
ss   = dVdx + dUdy;
LOW  = sn.^2 + ss.^2 - zeta.^2;

% ---------------- LNAM ----------------
LNAM = compute_lnam_local(xm, ym, UU, VV, opt.SearchRadiusKm*1000);

% ---------------- candidate centers ----------------
ismax = local_extrema_2d(LNAM, 'max');
ismin = local_extrema_2d(LNAM, 'min');

candCycl  = ismax & (LNAM >=  opt.MinAbsLNAM) & (LOW < 0) & inside_exact & isfinite(LNAM);
candAnti  = ismin & (LNAM <= -opt.MinAbsLNAM) & (LOW < 0) & inside_exact & isfinite(LNAM);
candAll   = candCycl | candAnti;

[ic, jc]  = find(candAll);
if isempty(ic)
    warning('No AMEDA-like candidate centers found in the box.');
    eddies = struct([]);
    return
end

center_lon  = X(candAll);
center_lat  = Y(candAll);
center_lnam = LNAM(candAll);
center_low  = LOW(candAll);
center_sign = sign(center_lnam);

% ---------------- pseudo-streamfunction ----------------
% If you have ADT/SSH available, replacing psi by ADT here is better.
psi_x = cumtrapz(xvec, VV, 2);     % dpsi/dx = v
psi_y = -cumtrapz(yvec, UU, 1);    % dpsi/dy = -u
% psi   = 0.5 * (psi_x + psi_y);
psi   = 9.8./coriolis(Y).* AA;

speed = hypot(UU, VV);

% ---------------- contour levels ----------------
psiv = psi(isfinite(psi));
if numel(psiv) < 20
    warning('Pseudo-streamfunction has too few valid points.');
    eddies = struct([]);
    return
end
levels = linspace(min(psiv), max(psiv), opt.NLevels);

% ---------------- detect eddies around each center ----------------
eddies = struct( ...
    'center_lon', {}, 'center_lat', {}, 'sign', {}, 'lnam', {}, 'low', {}, ...
    'char_lon', {}, 'char_lat', {}, 'char_level', {}, 'char_mean_speed', {}, ...
    'outer_lon', {}, 'outer_lat', {}, 'outer_level', {}, ...
    'outer_area_km2', {}, 'outer_compactness', {}, 'outer_convex_def', {});

for kk = 1:numel(center_lon)

    lonc = center_lon(kk);
    latc = center_lat(kk);

    contourCandidates = struct( ...
        'level', {}, 'xy', {}, 'area_km2', {}, ...
        'compactness', {}, 'convex_def', {}, 'mean_speed', {});

    for ilev = 1:numel(levels)
        S = get_closed_contours(X, Y, psi, levels(ilev));

        for jj = 1:numel(S)
            xy = S(jj).xy;

            % Must enclose this center
            inThis = inpolygon(lonc, latc, xy(:,1), xy(:,2));
            if ~inThis
                continue
            end

            % Must not include another candidate center
            inCenters = inpolygon(center_lon, center_lat, xy(:,1), xy(:,2));
            if sum(inCenters) ~= 1
                continue
            end

            % Geometry filters
            [xc, yc] = lonlat2xy_local(xy(:,1), xy(:,2), lon0, lat0);
            A = polyarea(xc, yc);
            P = sum(hypot(diff(xc), diff(yc)));
            if ~isfinite(A) || ~isfinite(P) || A <= 0 || P <= 0
                continue
            end

            area_km2 = A / 1e6;
            compactness = 4*pi*A/(P^2);

            try
                kh = convhull(xc, yc);
                Ah = polyarea(xc(kh), yc(kh));
                convex_def = (Ah - A) / Ah;
            catch
                convex_def = Inf;
            end

            if area_km2 < opt.MinAreaKm2
                continue
            end
            if compactness < opt.MinCompactness
                continue
            end
            if convex_def > opt.MaxConvexDef
                continue
            end

            % Mean speed along the streamline
            spc = interp2(X, Y, speed, xy(:,1), xy(:,2), 'linear', NaN);
            mean_speed = mean(spc, 'omitnan');
            if ~isfinite(mean_speed)
                continue
            end

            n = numel(contourCandidates) + 1;
            contourCandidates(n).level       = S(jj).level;
            contourCandidates(n).xy          = xy;
            contourCandidates(n).area_km2    = area_km2;
            contourCandidates(n).compactness = compactness;
            contourCandidates(n).convex_def  = convex_def;
            contourCandidates(n).mean_speed  = mean_speed;
        end
    end

    if isempty(contourCandidates)
        continue
    end

    % Characteristic contour = maximum mean speed
    [~, iChar] = max([contourCandidates.mean_speed]);

    % Outer contour = largest valid closed contour
    [~, iOut]  = max([contourCandidates.area_km2]);

    nE = numel(eddies) + 1;
    eddies(nE).center_lon         = lonc;
    eddies(nE).center_lat         = latc;
    eddies(nE).sign               = center_sign(kk);
    eddies(nE).lnam               = center_lnam(kk);
    eddies(nE).low                = center_low(kk);

    eddies(nE).char_lon           = contourCandidates(iChar).xy(:,1);
    eddies(nE).char_lat           = contourCandidates(iChar).xy(:,2);
    eddies(nE).char_level         = contourCandidates(iChar).level;
    eddies(nE).char_mean_speed    = contourCandidates(iChar).mean_speed;

    eddies(nE).outer_lon          = contourCandidates(iOut).xy(:,1);
    eddies(nE).outer_lat          = contourCandidates(iOut).xy(:,2);
    eddies(nE).outer_level        = contourCandidates(iOut).level;
    eddies(nE).outer_area_km2     = contourCandidates(iOut).area_km2;
    eddies(nE).outer_compactness  = contourCandidates(iOut).compactness;
    eddies(nE).outer_convex_def   = contourCandidates(iOut).convex_def;
end

if isempty(eddies)
    warning('No valid AMEDA-like contours survived the geometric filters.');
    return
end

% Sort by characteristic contour mean speed
[~, isrt] = sort([eddies.char_mean_speed], 'descend');
eddies = eddies(isrt);

% ---------------- plot ----------------
if opt.PlotIt
    figure
    pcolor(X, Y, LOW), shading flat
    hold on
    cli = get(gca, 'clim');
    quiver(X, Y, UU, VV, 'k')
    contour(X, Y, psi, 12, 'k-')
    for k = 1:numel(eddies)
        if eddies(k).sign > 0
            cc = 'r';
        else
            cc = 'c';
        end
        plot(eddies(k).outer_lon, eddies(k).outer_lat, '-', 'Color', cc, 'LineWidth', 1.8)
        plot(eddies(k).char_lon,  eddies(k).char_lat,  '--', 'Color', cc, 'LineWidth', 1.2)
        plot(eddies(k).center_lon, eddies(k).center_lat, 'o', ...
             'Color', cc, 'MarkerFaceColor', cc, 'MarkerSize', 5)
        text(eddies(k).center_lon, eddies(k).center_lat, sprintf(' %d',k), ...
             'Color', 'w', 'FontWeight', 'bold', 'VerticalAlignment', 'bottom')
    end
    xlim(lonbox)
    ylim(latbox)
    colorbar
    clim(cli)
    xlabel('Longitude')
    ylabel('Latitude')
    title('Light AMEDA-style eddy detection')
end

end

% ============================================================
function LNAM = compute_lnam_local(xm, ym, U, V, R)
% Local normalized angular momentum on a circular neighborhood.

[ny, nx] = size(U);
LNAM = nan(ny, nx);

dx = median(diff(xm(1,:)), 'omitnan');
dy = median(diff(ym(:,1)), 'omitnan');

nxr = max(1, ceil(R / abs(dx)));
nyr = max(1, ceil(R / abs(dy)));

for i = 1:ny
    for j = 1:nx

        if ~isfinite(U(i,j)) || ~isfinite(V(i,j))
            continue
        end

        i1 = max(1, i-nyr);  i2 = min(ny, i+nyr);
        j1 = max(1, j-nxr);  j2 = min(nx, j+nxr);

        xr = xm(i1:i2, j1:j2) - xm(i,j);
        yr = ym(i1:i2, j1:j2) - ym(i,j);
        ur = U(i1:i2, j1:j2);
        vr = V(i1:i2, j1:j2);

        rr = hypot(xr, yr);
        vv = hypot(ur, vr);

        good = isfinite(ur) & isfinite(vr) & rr > 0 & rr <= R;
        if nnz(good) < 8
            continue
        end

        L = sum(xr(good).*vr(good) - yr(good).*ur(good), 'omitnan');
        S = sum(xr(good).*ur(good) + yr(good).*vr(good), 'omitnan');
        B = sum(rr(good).*vv(good), 'omitnan');

        den = S + B;
        if abs(den) > eps
            LNAM(i,j) = L / den;
        end
    end
end
end

% ============================================================
function BW = local_extrema_2d(Z, mode)
% Strict 8-neighbor extrema
[ny, nx] = size(Z);
BW = false(ny, nx);

for i = 2:ny-1
    for j = 2:nx-1
        z0 = Z(i,j);
        if ~isfinite(z0)
            continue
        end
        nb = Z(i-1:i+1, j-1:j+1);
        nb(2,2) = NaN;
        nb = nb(isfinite(nb));
        if isempty(nb)
            continue
        end

        switch lower(mode)
            case 'max'
                BW(i,j) = all(z0 >= nb) && any(z0 > nb);
            case 'min'
                BW(i,j) = all(z0 <= nb) && any(z0 < nb);
            otherwise
                error('mode must be ''max'' or ''min''.')
        end
    end
end
end

% ============================================================
function S = get_closed_contours(X, Y, Z, level)
C = contourc(X(1,:), Y(:,1), Z, [level level]);

S = struct('level',{},'xy',{});
k = 1;
ic = 0;

while k < size(C,2)
    lev = C(1,k);
    npt = C(2,k);
    pts = C(:,k+1:k+npt)';
    k = k + npt + 1;

    if size(pts,1) < 4
        continue
    end

    if hypot(pts(1,1)-pts(end,1), pts(1,2)-pts(end,2)) < 1e-6
        ic = ic + 1;
        S(ic).level = lev;
        S(ic).xy    = pts;
    end
end
end

% ============================================================
function [x, y] = lonlat2xy_local(lon, lat, lon0, lat0)
R = 6371000; % m
x = R * cosd(lat0) * deg2rad(lon - lon0);
y = R * deg2rad(lat - lat0);
end

% ============================================================
function K = gaussian_kernel_2d(sig)
if sig <= 0
    K = 1;
    return
end
n = max(1, ceil(3*sig));
[x, y] = meshgrid(-n:n, -n:n);
K = exp(-(x.^2 + y.^2)/(2*sig^2));
K = K / sum(K(:));
end

% ============================================================
function Zs = nanconv2(Z, K)
M = isfinite(Z);
Z0 = Z;
Z0(~M) = 0;

num = conv2(Z0, K, 'same');
den = conv2(double(M), K, 'same');

Zs = num ./ den;
Zs(den == 0) = NaN;
end