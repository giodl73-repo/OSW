function plot_Figures5_7
% Reproduce manuscript Figures 5-7 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','Figures5_7_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir), mkdir(outDir); end
balance = divergingMap(256);

%% Figure 5

fig = figure('Color','w','Position',[40 40 1250 900]);
tl = tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
ax = nexttile(tl,[2 1]);

mapPattern = nan(size(data.xdu));
mapPattern(data.inma) = data.E_2(:,2);
sectionPattern = nan(size(data.Xy));
sectionPattern(data.celday) = data.E_1(:,2);
sectionLatitude = interp1(data.xsecy,data.ysecy,data.Xy,'linear','extrap');

surf(ax,data.xdu,data.ydu,zeros(size(data.xdu)),mapPattern,'EdgeColor','none');
hold(ax,'on');
surf(ax,data.Xy,sectionLatitude,data.Zy,sectionPattern,'EdgeColor','none');
plot3(ax,[data.m2.P1(1) data.m2.P2(1)],[data.m2.P1(2) data.m2.P2(2)],[30 30], ...
    'sk','MarkerFaceColor','w');
view(ax,32,40); axis(ax,[-92 -81 20 29 -2100 100]);
grid(ax,'on'); box(ax,'on'); colormap(ax,balance); clim(ax,[-0.3 0.3]); colorbar(ax);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); zlabel(ax,'Depth (m)');
title(ax,sprintf('(a) Second MCA patterns; squared covariance = %.1f%%',data.VE(2)));

ax = nexttile(tl);
plot(ax,data.tisp,data.ycT(:),'Color',[0.45 0.45 0.45],'LineWidth',1);
ylabel(ax,'Transport (Sv)'); yyaxis(ax,'right');
plot(ax,data.tisp,data.T1_2(:),'Color',[0.10 0.35 0.85],'LineWidth',1);
ylabel(ax,'Yucatan MCA PC'); grid(ax,'on'); xlim(ax,[data.tid(1) data.tid(end)]);
datetick(ax,'x','yyyy','keeplimits'); title(ax,'(b) Yucatan transport and mode-2 coefficient');

ax = nexttile(tl);
plot(ax,data.tisp,data.SSHdiff(:),'Color',[0.45 0.45 0.45],'LineWidth',1);
ylabel(ax,'Cross-current SSH (m)'); yyaxis(ax,'right');
plot(ax,data.tisp,data.T2_2(:),'Color',[0.90 0.30 0.10],'LineWidth',1);
ylabel(ax,'LC MCA PC'); xlabel(ax,'Year'); grid(ax,'on');
xlim(ax,[data.tid(1) data.tid(end)]); datetick(ax,'x','yyyy','keeplimits');
title(ax,'(c) Cross-current SSH difference and mode-2 coefficient');

formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure5.png'),'Resolution',300);

%% Figure 6

fig = figure('Color','w','Position',[40 40 1450 950]);
tl = tiledlayout(fig,3,4,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl,[1 2]);
plotCompositeMap(ax,data.xduf,data.yduf,data.Cmax2,data.Umax2,data.Vmax2, ...
    data.ADTmax2_a,data.ADTmax2,balance,'(a) Positive phase');
plot(ax,[data.m2.P1(1) data.m2.P2(1)],[data.m2.P1(2) data.m2.P2(2)], ...
    'sk','MarkerFaceColor','w');

ax = nexttile(tl,[1 2]);
plotCompositeMap(ax,data.xduf,data.yduf,data.Cmin2,data.Umin2,data.Vmin2, ...
    data.ADTmin2_a,data.ADTmin2,balance,'(b) Negative phase');
plot(ax,[data.m2.P1(1) data.m2.P2(1)],[data.m2.P1(2) data.m2.P2(2)], ...
    'sk','MarkerFaceColor','w');

ax = nexttile(tl); plotSection(ax,data.Xy,data.Zy,data.Uymax2,balance,'(c) Yucatan, positive',false);
ax = nexttile(tl); plotSection(ax,data.Xf,data.Zf,data.Ufmax2,balance,'(d) Florida, positive',true);
ax = nexttile(tl); plotSection(ax,data.Xy,data.Zy,data.Uymin2,balance,'(e) Yucatan, negative',false);
ax = nexttile(tl); plotSection(ax,data.Xf,data.Zf,data.Ufmin2,balance,'(f) Florida, negative',true);

ax = nexttile(tl,[1 4]);
projected = -data.B2_f(:);
plot(ax,data.htimef,projected,'Color',[0.45 0.45 0.45],'LineWidth',1); hold(ax,'on');
plot(ax,data.tisp,data.T2_2(:),'Color',[0.95 0.55 0.05],'LineWidth',1);
plot(ax,data.htimef(data.imax2_lc),projected(data.imax2_lc),'.r','MarkerSize',8);
plot(ax,data.htimef(data.imin2_lc),projected(data.imin2_lc),'.b','MarkerSize',8);
grid(ax,'on'); xlim(ax,[data.htimef(1) data.htimef(end)]); datetick(ax,'x','yyyy','keeplimits');
xlabel(ax,'Year'); ylabel(ax,'Standardized coefficient');
title(ax,'(g) Projected second LC MCA coefficient, 1993-2025');

formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure6.png'),'Resolution',300);

%% Figure 7

evolution = load(fullfile(root,'data','Figure7_processed.mat'));
fig = figure('Color','w','Position',[20 30 1650 1000]);
tl = tiledlayout(fig,4,5,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl,1,[1 4]);
plotEventTimeline(ax,evolution.htime,evolution.projectedPC, ...
    evolution.positive.onsetDates,evolution.positive.peakDates,'(a) Positive events');
ax = nexttile(tl,5);
plotNormalizedPC(ax,evolution.positive.pc,'(b) Positive evolution');
plotEvolutionMaps(tl,6,evolution,evolution.positive,balance,'(c)');

ax = nexttile(tl,11,[1 4]);
plotEventTimeline(ax,evolution.htime,evolution.projectedPC, ...
    evolution.negative.onsetDates,evolution.negative.peakDates,'(d) Negative events');
ax = nexttile(tl,15);
plotNormalizedPC(ax,evolution.negative.pc,'(e) Negative evolution');
plotEvolutionMaps(tl,16,evolution,evolution.negative,balance,'(f)');

sgtitle(tl,'Projected second MCA mode and time-normalized event evolution');
formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure7.png'),'Resolution',300);
end

function plotEventTimeline(ax,time,pc,onsetDates,peakDates,label)
plot(ax,time,pc,'Color',[0.70 0.70 0.70],'LineWidth',0.8); hold(ax,'on');
for i = 1:numel(peakDates)
    use = time >= onsetDates(i) & time <= peakDates(i);
    plot(ax,time(use),pc(use),'k','LineWidth',1.5);
end
[~,onsetIndex] = ismember(onsetDates,time);
[~,peakIndex] = ismember(peakDates,time);
plot(ax,time(onsetIndex),pc(onsetIndex),'.b','MarkerSize',11);
plot(ax,time(peakIndex),pc(peakIndex),'.r','MarkerSize',11);
grid(ax,'on'); box(ax,'on'); xlim(ax,[time(1) time(end)]);
datetick(ax,'x','yyyy','keeplimits'); ylabel(ax,'Projected MCA PC'); title(ax,label);
end

function plotNormalizedPC(ax,pc,label)
plot(ax,1:size(pc,1),pc,'Color',[0.75 0.75 0.75],'LineWidth',0.8); hold(ax,'on');
plot(ax,1:size(pc,1),mean(pc,2,'omitnan'),'k-o','LineWidth',1.7,'MarkerFaceColor','k');
set(ax,'XTick',1:size(pc,1),'XTickLabel',{'Onset','25%','50%','75%','Peak'});
grid(ax,'on'); box(ax,'on'); title(ax,label); ylabel(ax,'MCA PC');
end

function plotEvolutionMaps(layout,firstTile,data,event,cmap,panelLabel)
stages = {'Onset','25%','50%','75%','Peak'};
for i = 1:5
    ax = nexttile(layout,firstTile+i-1);
    anomaly = nan(size(data.xdu)); anomaly(data.inma) = event.adAnom(:,i);
    absolute = nan(size(data.xdu)); absolute(data.inma) = event.adAbs(:,i);
    u = nan(size(data.xdu)); u(data.inma) = event.u(:,i);
    v = nan(size(data.xdu)); v(data.inma) = event.v(:,i);
    pcolor(ax,data.xdu,data.ydu,anomaly); shading(ax,'interp'); hold(ax,'on');
    contour(ax,data.xdu,data.ydu,absolute,[0.55 0.55],'k','LineWidth',1.5);
    quiver(ax,data.xdu(1:5:end,1:5:end),data.ydu(1:5:end,1:5:end), ...
        u(1:5:end,1:5:end),v(1:5:end,1:5:end),1.5,'Color',[0.3 0.3 0.3]);
    axis(ax,'equal'); axis(ax,[-92 -81 18 29]); box(ax,'on');
    colormap(ax,cmap); clim(ax,[-0.3 0.3]); title(ax,stages{i});
    if i == 1, ylabel(ax,panelLabel); else, set(ax,'YTickLabel',[]); end
    xlabel(ax,'Longitude');
end
end

function plotCompositeMap(ax,x,y,speed,u,v,adtAnom,adtAbs,cmap,label)
pcolor(ax,x,y,speed); shading(ax,'interp'); hold(ax,'on');
quiver(ax,x(1:4:end,1:4:end),y(1:4:end,1:4:end), ...
    u(1:4:end,1:4:end),v(1:4:end,1:4:end),1.2,'k');
contour(ax,x,y,adtAnom,-0.24:0.06:0.30,'LineWidth',0.7);
contour(ax,x,y,adtAbs,[0.55 0.55],'Color',[0.95 0.70 0.05],'LineWidth',2);
axis(ax,'equal'); axis(ax,[-92 -80.9 18 29.2]); box(ax,'on');
colormap(ax,cmap); clim(ax,[-0.3 1.5]); xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); title(ax,label);
end

function plotSection(ax,x,z,v,cmap,label,reverseX)
contourf(ax,x,z,v,40,'EdgeColor','none'); hold(ax,'on');
contour(ax,x,z,v,[0 0],'k','LineWidth',1.5);
contour(ax,x,z,v,0.1:0.2:1.2,'r');
contour(ax,x,z,v,[-0.20 -0.10 -0.05 -0.03],':b');
set(ax,'Color',[0.72 0.72 0.72]); if reverseX, set(ax,'XDir','reverse'); end
ylim(ax,[-1400 100]); box(ax,'on'); colormap(ax,cmap); clim(ax,[-0.3 1.5]);
xlabel(ax,'Section coordinate'); ylabel(ax,'Depth (m)'); title(ax,label);
end

function map = divergingMap(n)
anchors = [0.12 0.32 0.70; 0.35 0.68 0.88; 0.95 0.95 0.95; ...
    0.90 0.55 0.42; 0.65 0.08 0.15];
map = interp1(linspace(0,1,size(anchors,1)),anchors,linspace(0,1,n));
end

function formatFigure(fig)
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',10);
end
