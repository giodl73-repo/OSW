function plot_Figures2_4
% Reproduce manuscript Figures 2-4 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root, 'data', 'Figures2_4_processed.mat'));
outDir = fullfile(root, 'figures');
if ~isfolder(outDir), mkdir(outDir); end

balance = divergingMap(256);

%% Figure 2

fig = figure('Color','w','Position',[40 40 1250 900]);
tl = tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
ax = nexttile(tl,[2 1]);

mapPattern = nan(size(data.xdu));
mapPattern(data.inma) = data.E_2(:,1);
sectionPattern = nan(size(data.Xy));
sectionPattern(data.celday) = data.E_1(:,1);
sectionLatitude = interp1(data.xsecy, data.ysecy, data.Xy, 'linear', 'extrap');

surf(ax,data.xdu,data.ydu,zeros(size(data.xdu)),mapPattern,'EdgeColor','none');
hold(ax,'on');
surf(ax,data.Xy,sectionLatitude,data.Zy,sectionPattern,'EdgeColor','none');
view(ax,32,40);
axis(ax,[-92 -81 20 29 -2100 100]);
grid(ax,'on'); box(ax,'on');
colormap(ax,balance); clim(ax,[-0.4 0.4]);
colorbar(ax);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); zlabel(ax,'Depth (m)');
title(ax,sprintf('(a) Leading MCA patterns; squared covariance = %.1f%%',data.VE(1)));

ax = nexttile(tl);
plot(ax,data.tisp,abs(data.xcury),'Color',[0.45 0.45 0.45],'LineWidth',1);
ylabel(ax,'Core longitude (degrees W)');
yyaxis(ax,'right');
plot(ax,data.tisp,data.T_1(:,1),'Color',[0.10 0.35 0.85],'LineWidth',1);
ylabel(ax,'Yucatan MCA PC');
grid(ax,'on'); xlim(ax,[data.tid(1) data.tid(end)]); datetick(ax,'x','yyyy','keeplimits');
title(ax,'(b) Yucatan Current core position and MCA coefficient');

ax = nexttile(tl);
area(ax,data.tid,data.AMR_loop(:)*1e-5,'FaceColor',[0.75 0.75 0.75], ...
    'EdgeColor','none','FaceAlpha',0.6);
hold(ax,'on');
plot(ax,data.tid,data.area_loop(:)*1e-5,'k','LineWidth',1);
ylabel(ax,'Area (10^5 km^2)');
yyaxis(ax,'right');
plot(ax,data.tisp,data.T_2(:,1),'Color',[0.90 0.30 0.10],'LineWidth',1);
ylabel(ax,'LC MCA PC'); xlabel(ax,'Year');
grid(ax,'on'); xlim(ax,[data.tid(1) data.tid(end)]); datetick(ax,'x','yyyy','keeplimits');
title(ax,'(c) Loop Current area and MCA coefficient');

formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure2.png'),'Resolution',300);

%% Figure 3

fig = figure('Color','w','Position',[40 40 1450 950]);
tl = tiledlayout(fig,3,4,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl,[1 2]);
plotCompositeMap(ax,data.xduf,data.yduf,data.Cmax,data.Umax,data.Vmax, ...
    data.ADTmax_a,data.ADTmax,data.CurAxisPositive,balance,'(a) Positive phase');

ax = nexttile(tl,[1 2]);
plotCompositeMap(ax,data.xduf,data.yduf,data.Cmin,data.Umin,data.Vmin, ...
    data.ADTmin_a,data.ADTmin,data.CurAxisNegative,balance,'(b) Negative phase');

ax = nexttile(tl);
plotSection(ax,data.Xy,data.Zy,data.Uymax,balance,'(c) Yucatan, positive',false);
ax = nexttile(tl);
plotSection(ax,data.Xf,data.Zf,data.Ufmax,balance,'(d) Florida, positive',true);
ax = nexttile(tl);
plotSection(ax,data.Xy,data.Zy,data.Uymin,balance,'(e) Yucatan, negative',false);
ax = nexttile(tl);
plotSection(ax,data.Xf,data.Zf,data.Ufmin,balance,'(f) Florida, negative',true);

ax = nexttile(tl,[1 4]);
plot(ax,data.htimef,data.B_k_f,'Color',[0.45 0.45 0.45],'LineWidth',1);
hold(ax,'on');
plot(ax,data.tisp,data.T_2(:,1),'Color',[0.95 0.55 0.05],'LineWidth',1);
plot(ax,data.htimef(data.inmax_lc),data.B_k_f(data.inmax_lc),'.r','MarkerSize',8);
plot(ax,data.htimef(data.inmin_lc),data.B_k_f(data.inmin_lc),'.b','MarkerSize',8);
grid(ax,'on'); xlim(ax,[data.htimef(1) data.htimef(end)]); datetick(ax,'x','yyyy','keeplimits');
ylabel(ax,'Standardized coefficient'); xlabel(ax,'Year');
title(ax,'(g) Projected leading LC MCA coefficient, 1993-2025');

formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure3.png'),'Resolution',300);

%% Figure 4

fig = figure('Color','w','Position',[40 40 1250 850]);
tl = tiledlayout(fig,3,1,'TileSpacing','compact','Padding','compact');
ax = nexttile(tl,[2 1]);

mapCorrelation = nan(size(data.xduf));
mapCorrelation(data.inmaf) = data.RRm_id;
sectionCorrelation = nan(size(data.Xyf));
sectionCorrelation(data.celdayf) = data.RRy_id;
sectionLatitude = interp1(data.xsecy,data.ysecy,data.Xyf,'linear','extrap');

surf(ax,data.xduf,data.yduf,zeros(size(data.xduf)),mapCorrelation,'EdgeColor','none');
hold(ax,'on');
surf(ax,data.Xyf,sectionLatitude,data.Zyf,sectionCorrelation,'EdgeColor','none');
view(ax,32,40); axis(ax,[-92 -81 20 29 -2100 100]);
grid(ax,'on'); box(ax,'on'); colormap(ax,balance); clim(ax,[-0.7 0.7]); colorbar(ax);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); zlabel(ax,'Depth (m)');
title(ax,'(a) Correlation with time-integrated deep-transport anomalies');

ax = nexttile(tl);
plot(ax,data.tid,data.AMR_loop(:)*1e-5,'k','LineWidth',1);
ylabel(ax,'LC + ring area (10^5 km^2)');
yyaxis(ax,'right');
deepIntegral = data.dum3(:)*86400*1e-7;
plot(ax,data.DeepTime,deepIntegral,'Color',[0.85 0.33 0.10],'LineWidth',1);
ylabel(ax,'Integrated transport (10^4 km^3)');
xlabel(ax,'Year'); grid(ax,'on'); xlim(ax,[data.tid(1) data.tid(end)]);
datetick(ax,'x','yyyy','keeplimits');
title(ax,'(b) Loop Current area and integrated deep transport');

formatFigure(fig);
exportgraphics(fig,fullfile(outDir,'Figure4.png'),'Resolution',300);
end

function plotCompositeMap(ax,x,y,speed,u,v,adtAnom,adtAbs,currentAxis,cmap,label)
pcolor(ax,x,y,speed); shading(ax,'interp'); hold(ax,'on');
quiver(ax,x(1:4:end,1:4:end),y(1:4:end,1:4:end), ...
    u(1:4:end,1:4:end),v(1:4:end,1:4:end),1.2,'k');
contour(ax,x,y,adtAnom,-0.24:0.06:0.30,'LineWidth',0.7);
contour(ax,x,y,adtAbs,[0.55 0.55],'Color',[0.95 0.70 0.05],'LineWidth',2);
plot(ax,currentAxis(:,1),currentAxis(:,2),'Color',[0.95 0.70 0.05],'LineWidth',1.5);
axis(ax,'equal'); axis(ax,[-92 -80.9 21.4 29.2]);
box(ax,'on'); colormap(ax,cmap); clim(ax,[-0.3 1.5]);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); title(ax,label);
end

function plotSection(ax,x,z,v,cmap,label,reverseX)
contourf(ax,x,z,v,40,'EdgeColor','none'); hold(ax,'on');
contour(ax,x,z,v,[0 0],'k','LineWidth',1.5);
contour(ax,x,z,v,0.1:0.2:1.2,'r');
contour(ax,x,z,v,[-0.20 -0.10 -0.05 -0.03],':b');
set(ax,'Color',[0.72 0.72 0.72]);
if reverseX, set(ax,'XDir','reverse'); end
ylim(ax,[-1400 100]); box(ax,'on'); colormap(ax,cmap); clim(ax,[-0.3 1.5]);
xlabel(ax,'Section coordinate'); ylabel(ax,'Depth (m)'); title(ax,label);
end

function map = divergingMap(n)
anchors = [0.12 0.32 0.70; 0.35 0.68 0.88; 0.95 0.95 0.95; ...
    0.90 0.55 0.42; 0.65 0.08 0.15];
map = interp1(linspace(0,1,size(anchors,1)),anchors,linspace(0,1,n));
end

function formatFigure(fig)
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',10);
end
