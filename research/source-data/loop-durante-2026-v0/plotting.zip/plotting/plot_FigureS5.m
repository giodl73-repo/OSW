function plot_FigureS5
% Reproduce manuscript Supplementary Figure S5 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','FigureS5_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir), mkdir(outDir); end
cmap = divergingMap(256);

fig = figure('Color','w','Position',[30 60 1500 850]);
tl = tiledlayout(fig,2,3,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl,[2 1]); hold(ax,'on');
use = data.Results.HasCritical & data.Results.SeparationResolved & ...
    isfinite(data.Results.DetachmentColor);
scatter(ax,data.Results.SeparationLon(use),data.Results.SeparationLat(use),70, ...
    data.Results.DetachmentColor(use), 'filled','MarkerEdgeColor','k');
yline(ax,24,'--','24 N'); yline(ax,26,'--','26 N');
axis(ax,'equal'); axis(ax,[-88.8 -84.7 21 29]); grid(ax,'on'); box(ax,'on');
colormap(ax,cmap);
values = sort(abs(data.Results.DetachmentColor(use)));
if isempty(values)
    limit = 1;
else
    limit = values(max(1,round(0.98*numel(values))));
end
if ~isfinite(limit) || limit == 0, limit = 1; end
clim(ax,[-limit limit]);
xlabel(ax,'Detachment longitude'); ylabel(ax,'Detachment latitude');
title(ax,sprintf('(a) All detachments; preceding mode-2 critical point (%d-day lookback)', ...
    data.lookbackDays));
cb1 = colorbar(ax,'southoutside'); ylabel(cb1,'Mode-2-implied YC transport anomaly (%)');

ax = nexttile(tl,2);
plotComposite(ax,data.xdu,data.ydu,data.CompNegAnom,data.CompNegAbs, ...
    data.ringContourLevel,cmap,sprintf('(b) Preceded by negative critical point, n = %d',data.nNegComp));

ax = nexttile(tl,3);
plotComposite(ax,data.xdu,data.ydu,data.CompPosAnom,data.CompPosAbs, ...
    data.ringContourLevel,cmap,sprintf('(c) Preceded by positive critical point, n = %d',data.nPosComp));

ax = nexttile(tl,5);
plotComposite(ax,data.xdu,data.ydu,data.CompNegNoDetAnom,data.CompNegNoDetAbs, ...
    data.ringContourLevel,cmap,sprintf('(d) Negative peak, no detachment, n = %d',data.nNegNoDetComp));

ax = nexttile(tl,6);
plotComposite(ax,data.xdu,data.ydu,data.CompPosNoDetAnom,data.CompPosNoDetAbs, ...
    data.ringContourLevel,cmap,sprintf('(e) Positive peak, no detachment, n = %d',data.nPosNoDetComp));

cb = colorbar(ax); cb.Layout.Tile = 'east'; ylabel(cb,'Sea-level anomaly (m)');
sgtitle(tl,'Detachment locations and composites conditioned on preceding mode-2 extrema');
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',10);
exportgraphics(fig,fullfile(outDir,'FigureS5.png'),'Resolution',300);
end

function plotComposite(ax,x,y,anom,absolute,level,cmap,label)
pcolor(ax,x,y,anom); shading(ax,'interp'); hold(ax,'on');
contour(ax,x,y,absolute,[level level],'k','LineWidth',2);
axis(ax,'equal'); axis(ax,[-92.2 -81 18 29]); box(ax,'on');
colormap(ax,cmap); clim(ax,[-0.35 0.35]);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude'); title(ax,label);
end

function map = divergingMap(n)
anchors = [0.12 0.32 0.70; 0.35 0.68 0.88; 0.95 0.95 0.95; ...
    0.90 0.55 0.42; 0.65 0.08 0.15];
map = interp1(linspace(0,1,size(anchors,1)),anchors,linspace(0,1,n));
end
