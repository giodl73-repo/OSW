function plot_Figure9
% Reproduce manuscript Figure 9 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','Figure9_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir), mkdir(outDir); end

fig = figure('Color','w','Position',[20 20 1550 1100]);
tl = tiledlayout(fig,4,4,'TileSpacing','compact','Padding','compact');

for row = 1:3
    ax = nexttile(tl,(row-1)*4+1);
    skill = nan(size(data.xdu)); skill(data.inma) = data.skillR2(:,row);
    pcolor(ax,data.xdu,data.ydu,skill); shading(ax,'interp');
    axis(ax,'equal'); axis(ax,[-92 -80.9 21.4 29.2]); box(ax,'on');
    colormap(ax,parula(256)); clim(ax,[0 1]);
    title(ax,sprintf('Testing R^2, lead %d d',data.leads(row)));
    ylabel(ax,'Latitude');
    if row < 3, set(ax,'XTickLabel',[]); else, xlabel(ax,'Longitude'); end
end

for col = 1:3
    ax = nexttile(tl,1+col);
    plotField(ax,data,data.observed(col),sprintf('Observed: %s', ...
        datestr(data.exampleDates(col),'dd-mmm-yyyy')));
    set(ax,'XTickLabel',[]);

    ax = nexttile(tl,5+col);
    plotField(ax,data,data.predicted(1,col),sprintf('Reconstruction, lead 0 d'));
    set(ax,'XTickLabel',[]);

    ax = nexttile(tl,9+col);
    plotField(ax,data,data.predicted(2,col),sprintf('Reconstruction, lead 20 d'));
    xlabel(ax,'Longitude');
end

ax = nexttile(tl,[1 4]);
area(ax,data.timeline,data.LCEddyArea(:)*1e-5,'FaceColor',[0.75 0.75 0.75], ...
    'EdgeColor','none','FaceAlpha',0.65);
hold(ax,'on');
plot(ax,data.timeline,data.LCArea(:)*1e-5,'k','LineWidth',1);
for date = data.exampleDates(:)'
    xline(ax,date,'r','LineWidth',1);
end
if all(isfinite(data.canekGap))
    patch(ax,[data.canekGap(1) data.canekGap(2) data.canekGap(2) data.canekGap(1)], ...
        [0 0 2.5 2.5],[1 1 1],'EdgeColor','none','FaceAlpha',0.85);
end
patch(ax,[data.testPeriod(1) data.testPeriod(2) data.testPeriod(2) data.testPeriod(1)], ...
    [0 0 2.5 2.5],[1.0 0.75 0.25],'EdgeColor','none','FaceAlpha',0.18);
plot(ax,data.timeline,data.LCArea(:)*1e-5,'k','LineWidth',1);
xlim(ax,[data.timeline(1) data.timeline(end)]); ylim(ax,[0 2.5]);
datetick(ax,'x','yyyy','keeplimits'); grid(ax,'on');
xlabel(ax,'Year'); ylabel(ax,'Area (10^5 km^2)');
title(ax,'LC area, testing interval, Canek gap, and example dates');

sgtitle(tl,'Observed and Canek-based linear reconstructions of the Loop Current');
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',9);
exportgraphics(fig,fullfile(outDir,'Figure9.png'),'Resolution',300);
end

function plotField(ax,data,field,label)
speed = toGrid(field.mg,data.xdu,data.inma);
u = toGrid(field.ug,data.xdu,data.inma);
v = toGrid(field.vg,data.xdu,data.inma);
adt = toGrid(field.ad,data.xdu,data.inma);
pcolor(ax,data.xdu,data.ydu,speed); shading(ax,'interp'); hold(ax,'on');
quiver(ax,data.xdu(1:5:end,1:5:end),data.ydu(1:5:end,1:5:end), ...
    u(1:5:end,1:5:end),v(1:5:end,1:5:end),1.3,'Color',[0.3 0.3 0.3]);
contour(ax,data.xdu,data.ydu,adt,[0.55 0.55], ...
    'Color',[0.95 0.70 0.05],'LineWidth',1.7);
axis(ax,'equal'); axis(ax,[-92 -80.9 21.4 29.2]); box(ax,'on');
colormap(ax,turbo(256)); clim(ax,[0 1.4]); title(ax,label);
set(ax,'YTickLabel',[]);
end

function grid = toGrid(vector,template,index)
grid = nan(size(template));
grid(index) = vector(:);
end
