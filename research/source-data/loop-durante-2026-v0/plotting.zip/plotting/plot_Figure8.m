function plot_Figure8
% Reproduce manuscript Figure 8 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','Figure8_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir), mkdir(outDir); end

fig = figure('Color','w','Position',[20 60 1650 850]);
tl = tiledlayout(fig,3,numel(data.lags),'TileSpacing','compact','Padding','compact');
cmap = divergingMap(256);
fields = {data.RR_x,data.RR_y,data.RR_multi};
rowNames = {'(a) Core position','(b) Yucatan Current transport', ...
    '(c) Core position + transport'};

for row = 1:3
    for col = 1:numel(data.lags)
        ax = nexttile(tl,(row-1)*numel(data.lags)+col);
        map = nan(size(data.xdu));
        map(data.inma) = fields{row}(:,col);
        pcolor(ax,data.xdu,data.ydu,map); shading(ax,'interp'); hold(ax,'on');
        contour(ax,data.xdu,data.ydu,map,[-0.3 -0.3],'--k');
        contour(ax,data.xdu,data.ydu,map,[0.3 0.3],'k');
        axis(ax,'equal'); axis(ax,[-92 -75.5 14.2 29.2]); box(ax,'on');
        colormap(ax,cmap); clim(ax,[-0.8 0.8]);
        title(ax,sprintf('Lag %g days',data.lags(col)));
        if col == 1
            ylabel(ax,rowNames{row});
        else
            set(ax,'YTickLabel',[]);
        end
        if row < 3, set(ax,'XTickLabel',[]); else, xlabel(ax,'Longitude'); end
    end
end

cb = colorbar(ax); cb.Layout.Tile = 'east'; ylabel(cb,'Correlation');
sgtitle(tl,'Lagged relationships between Yucatan Current metrics and surface geostrophic speed');
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',10);
exportgraphics(fig,fullfile(outDir,'Figure8.png'),'Resolution',300);
end

function map = divergingMap(n)
anchors = [0.12 0.32 0.70; 0.35 0.68 0.88; 0.95 0.95 0.95; ...
    0.90 0.55 0.42; 0.65 0.08 0.15];
map = interp1(linspace(0,1,size(anchors,1)),anchors,linspace(0,1,n));
end
