function plot_Figure10
% Reproduce manuscript Figure 10 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','Figure10_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir), mkdir(outDir); end
F = data.Figure10;
cmap = divergingMap(256);

fig = figure('Color','w','Position',[40 40 1250 950]);
tl = tiledlayout(fig,2,2,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl);
plotComposite(ax,data,F.PostCompMeander,cmap, ...
    '(a) Negative mode-2 extrema followed by detachment');
plotRings(ax,F.RingMeander);

ax = nexttile(tl);
plotComposite(ax,data,F.PostCompMildner,cmap, ...
    '(b) Positive mode-2 extrema followed by detachment');
plotRings(ax,F.RingMildner);

ax = nexttile(tl);
plotComposite(ax,data,F.NoDetCompMeander,cmap, ...
    '(c) Negative mode-2 extrema without detachment');
text(ax,0.03,0.08,sprintf('%d/%d cases',F.NoDetCompMeander.n,height(F.MeanderMatch)), ...
    'Units','normalized','FontWeight','bold');

ax = nexttile(tl);
plotComposite(ax,data,F.NoDetCompMildner,cmap, ...
    '(d) Positive mode-2 extrema without detachment');
text(ax,0.03,0.08,sprintf('%d/%d cases',F.NoDetCompMildner.n,height(F.MildnerMatch)), ...
    'Units','normalized','FontWeight','bold');

cb = colorbar(ax); cb.Layout.Tile = 'east'; ylabel(cb,'Sea-level anomaly (m)');
sgtitle(tl,sprintf('Mode-2 configurations and Loop Current detachment (%d-day window)', ...
    F.forwardWindowDays));
set(findall(fig,'-property','FontName'),'FontName','Arial');
set(findall(fig,'-property','FontSize'),'FontSize',10);
exportgraphics(fig,fullfile(outDir,'Figure10.png'),'Resolution',300);
end

function plotComposite(ax,data,comp,cmap,label)
pcolor(ax,data.xdu,data.ydu,comp.anomADT); shading(ax,'interp'); hold(ax,'on');
contour(ax,data.xdu,data.ydu,comp.absADT,[0.58 0.58],'k','LineWidth',2);
quiver(ax,data.xdu(1:5:end,1:5:end),data.ydu(1:5:end,1:5:end), ...
    comp.U(1:5:end,1:5:end),comp.V(1:5:end,1:5:end),1.5,'Color',[0.35 0.35 0.35]);
axis(ax,'equal'); axis(ax,[-92.2 -81 18 29]); box(ax,'on');
colormap(ax,cmap); clim(ax,[-0.35 0.35]);
xlabel(ax,'Longitude'); ylabel(ax,'Latitude');
title(ax,sprintf('%s, n = %d',label,comp.n));
end

function plotRings(ax,rings)
colors = turbo(max(2,numel(rings)));
for i = 1:numel(rings)
    if rings(i).Found && ~isempty(rings(i).Lon)
        plot(ax,rings(i).Lon,rings(i).Lat,'Color',colors(i,:),'LineWidth',1);
    end
end
end

function map = divergingMap(n)
anchors = [0.12 0.32 0.70; 0.35 0.68 0.88; 0.95 0.95 0.95; ...
    0.90 0.55 0.42; 0.65 0.08 0.15];
map = interp1(linspace(0,1,size(anchors,1)),anchors,linspace(0,1,n));
end
