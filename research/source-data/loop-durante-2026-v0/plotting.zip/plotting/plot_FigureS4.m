% function plot_FigureS4
% Reproduce manuscript Supplementary Figure S4 from compact processed data.
% G. Durante, 2026

root = fileparts(fileparts(mfilename('fullpath')));
data = load(fullfile(root,'data','FigureS4_processed.mat'));
outDir = fullfile(root,'figures');
if ~isfolder(outDir)
    mkdir(outDir);
end

fig = figure('Color','w','Position',[20 20 1600 1050]);
mapLimits = [-92 -80.9 21.4 29.2];
xPositions = [0.045 0.275 0.495 0.715];
mapSize = [0.205 0.245];

for index = 1:3
    ax = axes(fig,'Position',[xPositions(index+1) 0.675 mapSize]);
    plotField(ax,data,data.observed(index),mapLimits);
    title(ax,sprintf('Observed: %s', ...
        datestr(data.targetDates(index),'dd-mmm-yyyy')), ...
        'FontWeight','normal');
    set(ax,'XTickLabel',[],'YTickLabel',[]);
    if index == 1
        panelLabel(ax,'(a)');
    end
end

axSkill = axes(fig,'Position',[xPositions(1) 0.380 mapSize]);
skill = toGrid(data.skillR2,data.xdu,data.inma);
pcolor(axSkill,data.xdu,data.ydu,skill);
shading(axSkill,'interp');
formatMap(axSkill,mapLimits);
colormap(axSkill,parula(256));
clim(axSkill,[0 1]);
xlabel(axSkill,'Longitude');
ylabel(axSkill,'Latitude');
title(axSkill,sprintf('Testing R^2, lead %d days',data.lead), ...
    'FontWeight','normal');
panelLabel(axSkill,'(b)');

summaryText = sprintf('Mean R^2 = %.3f; reduction = %.1f%%', ...
    data.meanR2,data.relativeReduction);
text(axSkill,0.5,0.025,summaryText,'Units','normalized', ...
    'HorizontalAlignment','center','VerticalAlignment','bottom', ...
    'FontName','Arial','FontSize',9,'BackgroundColor','w','Margin',3);

skillBar = colorbar(axSkill,'southoutside');
skillBar.Position = [0.065 0.315 0.165 0.018];
skillBar.Label.String = 'Testing R^2';
skillBar.FontName = 'Arial';
skillBar.FontSize = 10;

for index = 1:3
    ax = axes(fig,'Position',[xPositions(index+1) 0.380 mapSize]);
    plotField(ax,data,data.predicted(index),mapLimits);
    title(ax,sprintf('Canek: %s; target: %s', ...
        datestr(data.predictorDates(index),'dd-mmm-yyyy'), ...
        datestr(data.targetDates(index),'dd-mmm-yyyy')), ...
        'FontWeight','normal');
    set(ax,'YTickLabel',[]);
    if index > 1
        set(ax,'XTickLabel',[]);
    else
        xlabel(ax,'Longitude');
    end
    if index == 1
        panelLabel(ax,'(c)');
    end
end

speedBar = colorbar(ax);
speedBar.Position = [0.945 0.380 0.013 0.540];
speedBar.Label.String = 'Geostrophic speed (m s^{-1})';
speedBar.FontName = 'Arial';
speedBar.FontSize = 10;

axTime = axes(fig,'Position',[0.045 0.075 0.875 0.155]);
% area(axTime,data.timeline,data.LCEddyArea(:)*1e-5, ...
    % 'FaceColor',[0.75 0.75 0.75],'EdgeColor','none','FaceAlpha',0.65);
hold(axTime,'on');
patch(axTime,[data.testPeriod(1) data.testPeriod(2) data.testPeriod(2) data.testPeriod(1)], ...
    [0 0 2.5 2.5],[1.0 0.75 0.25],'EdgeColor','none','FaceAlpha',0.20);
if all(isfinite(data.canekGap))
    patch(axTime,[data.canekGap(1) data.canekGap(2) data.canekGap(2) data.canekGap(1)], ...
        [0 0 2.5 2.5],[1 1 1],'EdgeColor','none','FaceAlpha',0.90);
end
lcLine = plot(axTime,data.timeline,data.LCArea(:)*1e-5,'k','LineWidth',1.2);
eddyPatch = patch(axTime,nan,nan,[0.75 0.75 0.75],'EdgeColor','none');
for exampleDate = data.targetDates(:)'
    xline(axTime,exampleDate,'r','LineWidth',1.2);
end
% if all(isfinite(data.canekGap))
    % xline(axTime,data.canekGap,'--k','LineWidth',1);
% end
xlim(axTime,[data.timeline(1) data.timeline(end)]);
ylim(axTime,[0 2.5]);
datetick(axTime,'x','yyyy','keeplimits');
box(axTime,'on');
grid(axTime,'on');
set(axTime,'Layer','top','FontName','Arial','FontSize',10,'TickDir','out');
xlabel(axTime,'Year');
ylabel(axTime,'Area (10^5 km^2)');
title(axTime,'Observed LC area, testing interval, Canek gap, and example dates', ...
    'FontWeight','normal');
% legend(axTime,[eddyPatch lcLine],{'Detached LC eddy area','LC area'}, ...
    % 'Location','northwest','Orientation','horizontal','Box','off');
panelLabel(axTime,'(d)');

annotation(fig,'textbox',[0.275 0.945 0.645 0.035], ...
    'String','Observed AVISO/CMEMS surface fields', ...
    'HorizontalAlignment','center','VerticalAlignment','middle', ...
    'EdgeColor','none','FontName','Arial','FontSize',13,'FontWeight','bold');
annotation(fig,'textbox',[0.275 0.640 0.645 0.035], ...
    'String','Linear reconstructions using Canek observations 40 days earlier', ...
    'HorizontalAlignment','center','VerticalAlignment','middle', ...
    'EdgeColor','none','FontName','Arial','FontSize',13,'FontWeight','bold');

exportgraphics(fig,fullfile(outDir,'FIG_S4_reconstruction_40d.png'), ...
    'Resolution',300);

fprintf('Figure S4 written to %s\n', ...
    fullfile(outDir,'FIG_S4_reconstruction_40d.png'));
% end

function plotField(ax,data,field,mapLimits)
speed = toGrid(field.mg,data.xdu,data.inma);
u = toGrid(field.ug,data.xdu,data.inma);
v = toGrid(field.vg,data.xdu,data.inma);
adt = toGrid(field.ad,data.xdu,data.inma);

pcolor(ax,data.xdu,data.ydu,speed);
shading(ax,'interp');
hold(ax,'on');
quiver(ax,data.xdu(1:5:end,1:5:end),data.ydu(1:5:end,1:5:end), ...
    u(1:5:end,1:5:end),v(1:5:end,1:5:end),1.3, ...
    'Color',[0.25 0.25 0.25]);
contour(ax,data.xdu,data.ydu,adt,[0.55 0.55], ...
    'Color',[0.95 0.70 0.05],'LineWidth',1.8);
formatMap(ax,mapLimits);
colormap(ax,turbo(256));
clim(ax,[0 1.4]);
end

function formatMap(ax,mapLimits)
axis(ax,'equal');
axis(ax,mapLimits);
box(ax,'on');
set(ax,'Layer','top','Color',[0.88 0.88 0.88], ...
    'FontName','Arial','FontSize',10,'TickDir','out', ...
    'TickLength',[0.004 0.004]);
xticks(ax,-90:2:-82);
yticks(ax,22:2:28);
xticklabels(ax,compose('%d^{\\circ}W',abs(xticks(ax))));
yticklabels(ax,compose('%d^{\\circ}N',yticks(ax)));
end

function panelLabel(ax,label)
text(ax,0.025,0.975,label,'Units','normalized', ...
    'VerticalAlignment','top','HorizontalAlignment','left', ...
    'FontName','Arial','FontSize',12,'FontWeight','bold', ...
    'BackgroundColor','w','Margin',2);
end

function grid = toGrid(vector,template,index)
grid = nan(size(template));
grid(index) = vector(:);
end
